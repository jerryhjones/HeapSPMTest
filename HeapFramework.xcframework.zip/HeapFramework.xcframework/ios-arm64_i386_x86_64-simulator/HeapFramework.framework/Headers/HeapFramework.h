//
//  HeapFramework.h
//  HeapFramework
//
//  Created by Jerry Jones on 12/28/20.
//  Copyright © 2020 Heap Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for HeapFramework.
FOUNDATION_EXPORT double HeapFrameworkVersionNumber;

//! Project version string for HeapFramework.
FOUNDATION_EXPORT const unsigned char HeapFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HeapFramework/PublicHeader.h>
#import <HeapFramework/Heap.h>


